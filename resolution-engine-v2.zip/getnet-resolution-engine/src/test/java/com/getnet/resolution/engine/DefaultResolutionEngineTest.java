package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.getnet.resolution.model.ResolutionConfig;
import com.getnet.resolution.model.ResolutionResult;
import com.getnet.resolution.repository.InMemoryResolutionConfigRepository;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class DefaultResolutionEngineTest {

    private static final TestScenarioLoader SCENARIO_LOADER = new TestScenarioLoader();

    @Test
    void shouldResolveUsingRootAndCurrentContexts() {
        var scenario = SCENARIO_LOADER.load("sf90-offerings");

        DefaultResolutionEngine engine = engineWithConfig(scenario.config());
        ResolutionResult result = engine.resolve("SF90", scenario.payloadJson());

        assertThat(result.actions()).hasSize(1);
        JsonNode action = result.actions().get(0).payload();
        assertThat(action.get("description").asText()).isEqualTo("Plano receive_now_2");
        assertThat(action.get("name").asText()).isEqualTo("item-1");
        assertThat(action.get("link").asText()).isEqualTo("http://teste.com/v1/offerings/offer-123/pricing");
        assertThat(action.get("raw").get("settlement_period").asText()).isEqualTo("receive_now_2");
    }

    @Test
    void shouldIgnoreOnlyTheTemplateObjectThatFailsInterpolation() {
        var scenario = SCENARIO_LOADER.load("sf90-missing-interpolation");

        DefaultResolutionEngine engine = engineWithConfig(scenario.config());
        ResolutionResult result = engine.resolve("SF90", scenario.payloadJson());

        assertThat(result.actions()).hasSize(1);
        assertThat(result.actions().get(0).payload().get("link").asText())
                .isEqualTo("http://teste.com/v1/items/item-1");
    }

    @Test
    void shouldReturnEmptyWhenThereIsNoConfigOrNoMatch() {
        DefaultResolutionEngine engineWithoutConfig = new DefaultResolutionEngine(new InMemoryResolutionConfigRepository());
        ResolutionResult noConfigResult = engineWithoutConfig.resolve("UNKNOWN", "{"a":1}");
        assertThat(noConfigResult.actions()).isEmpty();

        var scenario = SCENARIO_LOADER.load("sf90-no-match");
        DefaultResolutionEngine engineWithConfig = engineWithConfig(scenario.config());
        ResolutionResult noMatchResult = engineWithConfig.resolve("SF90", scenario.payloadJson());
        assertThat(noMatchResult.actions()).isEmpty();
    }

    @Test
    void shouldSupportMultipleRulesAndNumericOperators() {
        var scenario = SCENARIO_LOADER.load("sf90-installments");

        DefaultResolutionEngine engine = engineWithConfig(scenario.config());
        ResolutionResult result = engine.resolve("SF90", scenario.payloadJson());

        assertThat(result.actions()).hasSize(2);
        assertThat(result.actions())
                .extracting(action -> action.payload().get("kind").asText())
                .containsExactly("expensive", "cheap");
        assertThat(result.actions())
                .extracting(action -> action.payload().get("installment").asText())
                .containsExactly("i-2", "i-1");
    }

    @Test
    void shouldSupportDifferentApiShapeUsingRootPredicatesAndMultipleActions() {
        var scenario = SCENARIO_LOADER.load("credit-approval-offers");

        DefaultResolutionEngine engine = engineWithConfig(scenario.config());
        ResolutionResult result = engine.resolve("CR01", scenario.payloadJson());

        assertThat(result.actions()).hasSize(4);
        assertThat(result.actions())
                .extracting(action -> action.ruleId())
                .containsOnly("credit-eligible-offers");
        assertThat(result.actions())
                .extracting(action -> action.type())
                .containsExactly("URL", "MESSAGE", "URL", "MESSAGE");
        assertThat(result.actions())
                .extracting(action -> action.payload().get("offerId").asText())
                .containsExactly("offer-a", "offer-a", "offer-c", "offer-c");
        assertThat(result.actions().get(1).payload().get("text").asText())
                .isEqualTo("Cliente customer-9 elegível para oferta especial 12x");
    }

    @Test
    void shouldSupportInContainsAndArrayIndexInterpolationForAnotherApi() {
        var scenario = SCENARIO_LOADER.load("pricing-catalog");

        DefaultResolutionEngine engine = engineWithConfig(scenario.config());
        ResolutionResult result = engine.resolve("PC01", scenario.payloadJson());

        assertThat(result.actions()).hasSize(2);
        assertThat(result.actions())
                .extracting(action -> action.payload().get("sku").asText())
                .containsExactly("sku-1", "sku-3");
        assertThat(result.actions())
                .extracting(action -> action.payload().get("link").asText())
                .containsExactly(
                        "https://catalog.internal/products/sku-1/prices/BRL",
                        "https://catalog.internal/products/sku-3/prices/USD"
                );
        assertThat(result.actions())
                .extracting(action -> action.payload().get("channels").get(0).asText())
                .containsExactly("APP", "POS");
    }

    private static DefaultResolutionEngine engineWithConfig(ResolutionConfig config) {
        return new DefaultResolutionEngine(new InMemoryResolutionConfigRepository(config));
    }
}
