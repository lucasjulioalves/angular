package com.getnet.resolution.model;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Declarative condition evaluated against either the current item or the root payload.
 */
public record RulePredicate(
        PredicateScope scope,
        String path,
        Operator operator,
        JsonNode expectedValue
) {
    public RulePredicate {
        scope = scope == null ? PredicateScope.CURRENT : scope;
    }
}
