package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.getnet.resolution.model.ActionTemplate;
import com.getnet.resolution.model.ResolutionConfig;
import com.getnet.resolution.model.ResolutionResult;
import com.getnet.resolution.model.ResolutionRule;
import com.getnet.resolution.model.ResolvedAction;
import com.getnet.resolution.repository.ResolutionConfigRepository;

import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Default implementation of the resolution engine.
 *
 * <p>Design intent:</p>
 * <ul>
 *     <li>Keep the engine deterministic and infrastructure-agnostic.</li>
 *     <li>Separate selection, decision and rendering into explicit components.</li>
 *     <li>Honor the fail-safe requirement: one bad template item must not break the whole resolution.</li>
 * </ul>
 */
public final class DefaultResolutionEngine implements ResolutionEngine {

    private final ResolutionConfigRepository repository;
    private final ObjectMapper objectMapper;
    private final JsonPathQueryExecutor queryExecutor;
    private final PredicateEvaluator predicateEvaluator;
    private final TemplateInterpolator templateInterpolator;

    public DefaultResolutionEngine(ResolutionConfigRepository repository) {
        this(repository, new ObjectMapper());
    }

    public DefaultResolutionEngine(ResolutionConfigRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.queryExecutor = new JsonPathQueryExecutor(objectMapper);
        this.predicateEvaluator = new PredicateEvaluator(queryExecutor);
        this.templateInterpolator = new TemplateInterpolator(objectMapper);
    }

    @Override
    public ResolutionResult resolve(String errorCode, String payloadJson) {
        Optional<ResolutionConfig> configOptional = repository.findByErrorCode(errorCode);
        if (configOptional.isEmpty()) {
            return ResolutionResult.empty(errorCode);
        }

        JsonNode root = parse(payloadJson);
        List<ResolvedAction> resolvedActions = new ArrayList<>();

        ResolutionConfig config = configOptional.get();
        for (ResolutionRule rule : config.rules()) {
            resolveRule(errorCode, root, rule, resolvedActions);
        }

        return new ResolutionResult(errorCode, List.copyOf(resolvedActions));
    }

    private void resolveRule(String errorCode, JsonNode root, ResolutionRule rule, List<ResolvedAction> resolvedActions) {
        // selectionPath is the first stage of the engine: it defines the working set for the rule.
        // Every selected item becomes the local `value` context for predicates and interpolation.
        List<JsonNode> selectedItems = queryExecutor.read(root, rule.selectionPath());

        for (JsonNode current : selectedItems) {
            if (!predicateEvaluator.matchesAll(rule.predicates(), root, current)) {
                continue;
            }

            materializeActions(errorCode, root, rule, current, resolvedActions);
        }
    }

    private void materializeActions(
            String errorCode,
            JsonNode root,
            ResolutionRule rule,
            JsonNode current,
            List<ResolvedAction> resolvedActions
    ) {
        for (ActionTemplate actionTemplate : rule.actions()) {
            try {
                JsonNode resolvedPayload = templateInterpolator.interpolate(actionTemplate.template(), root, current);
                resolvedActions.add(new ResolvedAction(
                        errorCode,
                        rule.id(),
                        actionTemplate.type(),
                        resolvedPayload
                ));
            } catch (MissingInterpolationValueException ignored) {
                // Business rule:
                // if one rendered action cannot be fully interpolated, we drop only that action instance.
                // We do not fail the whole rule, and we do not fail the request.
            }
        }
    }

    private JsonNode parse(String payloadJson) {
        try {
            return objectMapper.readTree(payloadJson);
        } catch (Exception ex) {
            throw new UncheckedIOException(new java.io.IOException("Invalid payload JSON", ex));
        }
    }
}
