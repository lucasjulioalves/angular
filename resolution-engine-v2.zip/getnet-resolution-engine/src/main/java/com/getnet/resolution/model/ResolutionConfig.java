package com.getnet.resolution.model;

import java.util.Comparator;
import java.util.List;

/**
 * Root object stored in the repository for a given error code.
 * Rules are normalized by priority at construction time so the engine can execute them deterministically.
 */
public record ResolutionConfig(
        String errorCode,
        List<ResolutionRule> rules
) {
    public ResolutionConfig {
        rules = rules == null ? List.of() : rules.stream()
                .sorted(Comparator.comparing(ResolutionRule::priority))
                .toList();
    }
}
