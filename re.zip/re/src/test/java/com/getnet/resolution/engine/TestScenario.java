package com.getnet.resolution.engine;

import com.getnet.resolution.model.ResolutionConfig;

record TestScenario(ResolutionConfig config, String payloadJson) {
}
