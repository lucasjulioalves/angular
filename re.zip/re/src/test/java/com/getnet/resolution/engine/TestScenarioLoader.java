package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.getnet.resolution.model.ResolutionConfig;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Loads test scenarios from JSON resources.
 *
 * <p>This keeps the test code lean and makes it easy to inspect:</p>
 * <ul>
 *     <li>what would be persisted in Mongo</li>
 *     <li>which payload came from a given external API</li>
 * </ul>
 */
final class TestScenarioLoader {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    TestScenario load(String scenarioName) {
        ResolutionConfig config = readJson("scenarios/" + scenarioName + "/config.json", ResolutionConfig.class);
        String payloadJson = readText("scenarios/" + scenarioName + "/payload.json");
        return new TestScenario(config, payloadJson);
    }

    private <T> T readJson(String path, Class<T> type) {
        try (InputStream inputStream = resource(path)) {
            return OBJECT_MAPPER.readValue(inputStream, type);
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to load JSON resource: " + path, ex);
        }
    }

    private String readText(String path) {
        try (InputStream inputStream = resource(path)) {
            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to load text resource: " + path, ex);
        }
    }

    private InputStream resource(String path) {
        InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
        if (inputStream == null) {
            throw new IllegalArgumentException("Resource not found: " + path);
        }
        return inputStream;
    }
}
