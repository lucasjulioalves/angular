package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import java.util.ArrayList;
import java.util.List;

/**
 * Thin adapter over JsonPath.
 *
 * <p>Important behavior choices:</p>
 * <ul>
 *     <li>ALWAYS_RETURN_LIST keeps downstream code simple: selection always works with collections.</li>
 *     <li>SUPPRESS_EXCEPTIONS avoids blowing up the engine on missing paths.</li>
 * </ul>
 */
final class JsonPathQueryExecutor {

    private static final Configuration CONFIGURATION = Configuration.builder()
            .options(Option.ALWAYS_RETURN_LIST, Option.SUPPRESS_EXCEPTIONS)
            .build();

    private final ObjectMapper objectMapper;

    JsonPathQueryExecutor(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    List<JsonNode> read(JsonNode source, String path) {
        if (source == null || path == null || path.isBlank()) {
            return List.of();
        }

        List<?> raw = JsonPath.using(CONFIGURATION)
                .parse(source.toString())
                .read(path);

        List<JsonNode> result = new ArrayList<>(raw.size());
        for (Object value : raw) {
            result.add(objectMapper.valueToTree(value));
        }
        return result;
    }
}
