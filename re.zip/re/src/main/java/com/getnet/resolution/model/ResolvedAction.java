package com.getnet.resolution.model;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Final action emitted by the engine, ready for downstream consumption.
 */
public record ResolvedAction(
        String errorCode,
        String ruleId,
        String type,
        JsonNode payload
) {
}
