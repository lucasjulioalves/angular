package com.getnet.resolution.model;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.util.Comparator;
import java.util.List;

/**
 * Root object stored in the repository for a given error code.
 * Rules are normalized by priority at construction time so the engine can execute them deterministically.
 *
 * <p>The first field intentionally accepts both {@code errorCode} and {@code detailCode} when deserializing.
 * This keeps the engine compatible with older examples and with risk/detail-code driven configurations.</p>
 */
public record ResolutionConfig(
        @JsonAlias({"errorCode", "detailCode"}) String errorCode,
        List<ResolutionRule> rules
) {
    public ResolutionConfig {
        rules = rules == null ? List.of() : rules.stream()
                .sorted(Comparator.comparing(ResolutionRule::priority))
                .toList();
    }
}
