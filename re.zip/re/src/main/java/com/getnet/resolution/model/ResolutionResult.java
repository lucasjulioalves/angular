package com.getnet.resolution.model;

import java.util.List;

public record ResolutionResult(
        String errorCode,
        List<ResolvedAction> actions
) {
    public static ResolutionResult empty(String errorCode) {
        return new ResolutionResult(errorCode, List.of());
    }
}
