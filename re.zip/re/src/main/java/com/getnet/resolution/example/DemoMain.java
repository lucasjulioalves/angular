package com.getnet.resolution.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.getnet.resolution.engine.DefaultResolutionEngine;
import com.getnet.resolution.model.ResolutionResult;
import com.getnet.resolution.repository.InMemoryResolutionConfigRepository;

/**
 * Tiny executable example for manual exploration.
 */
public final class DemoMain {

    private DemoMain() {
    }

    public static void main(String[] args) throws Exception {
        String payload = """
                {
                  "offering": {
                    "id": "offer-123"
                  },
                  "filters": [
                    { "value": { "id": "item-1", "settlement_period": "receive_now_2" } },
                    { "value": { "id": "item-2", "settlement_period": "receive_later" } }
                  ]
                }
                """;

        DefaultResolutionEngine engine = new DefaultResolutionEngine(
                new InMemoryResolutionConfigRepository(ExampleConfigs.sf90Config())
        );

        ResolutionResult result = engine.resolve("SF90", payload);
        System.out.println(new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(result));
    }
}
