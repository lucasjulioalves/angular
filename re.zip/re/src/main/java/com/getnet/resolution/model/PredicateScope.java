package com.getnet.resolution.model;

public enum PredicateScope {
    CURRENT,
    ROOT
}
