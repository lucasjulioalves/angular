package com.getnet.resolution.model;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Template to be materialized after selection + predicate evaluation succeed.
 */
public record ActionTemplate(
        String type,
        JsonNode template
) {
}
