package com.getnet.resolution.repository;

import com.getnet.resolution.model.ResolutionConfig;

import java.util.Optional;

/**
 * Abstraction over the storage of rule configurations.
 * Production can use Mongo; tests can use an in-memory implementation.
 */
public interface ResolutionConfigRepository {
    Optional<ResolutionConfig> findByErrorCode(String errorCode);
}
