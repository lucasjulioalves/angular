package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.getnet.resolution.model.PredicateScope;
import com.getnet.resolution.model.RulePredicate;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Evaluates declarative predicates against the current execution context.
 *
 * <p>The engine deliberately keeps predicate logic explicit instead of embedding conditions in opaque strings.
 * This keeps validation, testing and future evolution tractable.</p>
 */
final class PredicateEvaluator {

    private final JsonPathQueryExecutor queryExecutor;
    private final TemplateInterpolator templateInterpolator;

    PredicateEvaluator(JsonPathQueryExecutor queryExecutor, TemplateInterpolator templateInterpolator) {
        this.queryExecutor = queryExecutor;
        this.templateInterpolator = templateInterpolator;
    }

    boolean matchesAll(List<RulePredicate> predicates, JsonNode root, JsonNode current) {
        if (predicates == null || predicates.isEmpty()) {
            return true;
        }

        for (RulePredicate predicate : predicates) {
            if (!matches(predicate, root, current)) {
                return false;
            }
        }
        return true;
    }

    boolean matches(RulePredicate predicate, JsonNode root, JsonNode current) {
        JsonNode scopedNode = predicate.scope() == PredicateScope.ROOT ? root : current;

        final List<JsonNode> actualValues;
        try {
            String resolvedPath = templateInterpolator.interpolatePath(predicate.path(), root, current);
            actualValues = queryExecutor.read(scopedNode, resolvedPath);
        } catch (MissingInterpolationValueException ex) {
            // Missing data for a dynamic predicate means the predicate does not match that item.
            return false;
        }

        return switch (predicate.operator()) {
            case EXISTS -> !actualValues.isEmpty() && actualValues.stream().anyMatch(this::isNotNull);
            case NOT_EXISTS -> actualValues.isEmpty() || actualValues.stream().noneMatch(this::isNotNull);
            case EQUALS -> anyEquals(actualValues, predicate.expectedValue());
            case NOT_EQUALS -> !anyEquals(actualValues, predicate.expectedValue());
            case IN -> anyIn(actualValues, predicate.expectedValue());
            case NOT_IN -> !anyIn(actualValues, predicate.expectedValue());
            case CONTAINS -> anyContains(actualValues, predicate.expectedValue());
            case GREATER_THAN -> anyNumericCompare(actualValues, predicate.expectedValue(), c -> c > 0);
            case GREATER_THAN_OR_EQUALS -> anyNumericCompare(actualValues, predicate.expectedValue(), c -> c >= 0);
            case LESS_THAN -> anyNumericCompare(actualValues, predicate.expectedValue(), c -> c < 0);
            case LESS_THAN_OR_EQUALS -> anyNumericCompare(actualValues, predicate.expectedValue(), c -> c <= 0);
        };
    }

    private boolean anyEquals(List<JsonNode> actualValues, JsonNode expectedValue) {
        return actualValues.stream().filter(this::isNotNull).anyMatch(actual -> nodesEqual(actual, expectedValue));
    }

    private boolean anyIn(List<JsonNode> actualValues, JsonNode expectedValue) {
        if (expectedValue == null || !expectedValue.isArray()) {
            return false;
        }

        Set<String> expectedSet = new HashSet<>();
        expectedValue.forEach(node -> expectedSet.add(normalizeComparableValue(node)));

        return actualValues.stream()
                .filter(this::isNotNull)
                .map(this::normalizeComparableValue)
                .anyMatch(expectedSet::contains);
    }

    private boolean anyContains(List<JsonNode> actualValues, JsonNode expectedValue) {
        if (expectedValue == null || expectedValue.isNull()) {
            return false;
        }

        for (JsonNode actual : actualValues) {
            if (!isNotNull(actual)) {
                continue;
            }

            if (actual.isArray()) {
                for (JsonNode item : actual) {
                    if (nodesEqual(item, expectedValue)) {
                        return true;
                    }
                }
                continue;
            }

            if (actual.isTextual() && expectedValue.isTextual()) {
                if (actual.asText().contains(expectedValue.asText())) {
                    return true;
                }
                continue;
            }

            if (nodesEqual(actual, expectedValue)) {
                return true;
            }
        }
        return false;
    }

    private boolean anyNumericCompare(List<JsonNode> actualValues, JsonNode expectedValue, NumericComparator comparator) {
        BigDecimal expected = asBigDecimal(expectedValue);
        if (expected == null) {
            return false;
        }

        for (JsonNode actual : actualValues) {
            BigDecimal actualDecimal = asBigDecimal(actual);
            if (actualDecimal != null && comparator.compare(actualDecimal.compareTo(expected))) {
                return true;
            }
        }
        return false;
    }

    private boolean nodesEqual(JsonNode actual, JsonNode expected) {
        if (!isNotNull(actual) || !isNotNull(expected)) {
            return false;
        }

        // Numeric values are normalized into BigDecimal so 100, 100.0 and "100" can be compared consistently.
        BigDecimal left = asBigDecimal(actual);
        BigDecimal right = asBigDecimal(expected);
        if (left != null && right != null) {
            return left.compareTo(right) == 0;
        }

        return Objects.equals(normalizeComparableValue(actual), normalizeComparableValue(expected));
    }

    private String normalizeComparableValue(JsonNode node) {
        if (node == null || node.isNull()) {
            return null;
        }
        if (node.isTextual()) {
            return node.asText();
        }
        if (node.isNumber()) {
            BigDecimal decimal = asBigDecimal(node);
            return decimal == null ? node.asText() : decimal.stripTrailingZeros().toPlainString();
        }
        if (node.isBoolean()) {
            return Boolean.toString(node.asBoolean());
        }
        return node.toString();
    }

    private BigDecimal asBigDecimal(JsonNode node) {
        if (node == null || node.isNull()) {
            return null;
        }
        try {
            if (node.isNumber()) {
                return node.decimalValue();
            }
            if (node.isTextual()) {
                return new BigDecimal(node.asText());
            }
            return null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private boolean isNotNull(JsonNode node) {
        return node != null && !node.isNull() && !node.isMissingNode();
    }

    @FunctionalInterface
    private interface NumericComparator {
        boolean compare(int result);
    }
}
