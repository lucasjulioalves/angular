package com.getnet.resolution.model;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Declarative condition evaluated against either the current item or the root payload.
 *
 * <p>The predicate can be fully static (constant expectedValue) or dynamic by using placeholders
 * inside the JsonPath itself, for example:</p>
 *
 * <pre>
 * $.offering.items[?(@.product.product_id == '${value.product.product_id}')]
 * </pre>
 *
 * <p>This allows cross-scope correlation without turning the engine into a scripting runtime.</p>
 */
public record RulePredicate(
        PredicateScope scope,
        String path,
        Operator operator,
        JsonNode expectedValue
) {
    public RulePredicate {
        scope = scope == null ? PredicateScope.CURRENT : scope;
    }
}
