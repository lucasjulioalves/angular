package com.getnet.resolution.repository;

import com.getnet.resolution.model.ResolutionConfig;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple repository used for tests, demos and local experimentation.
 * It exists to keep the engine decoupled from infrastructure concerns.
 */
public final class InMemoryResolutionConfigRepository implements ResolutionConfigRepository {

    private final Map<String, ResolutionConfig> configs = new ConcurrentHashMap<>();

    public InMemoryResolutionConfigRepository(ResolutionConfig... configs) {
        if (configs != null) {
            for (ResolutionConfig config : configs) {
                this.configs.put(config.errorCode(), config);
            }
        }
    }

    @Override
    public Optional<ResolutionConfig> findByErrorCode(String errorCode) {
        return Optional.ofNullable(configs.get(errorCode));
    }
}
