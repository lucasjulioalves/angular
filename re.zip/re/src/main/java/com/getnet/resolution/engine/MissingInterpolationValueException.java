package com.getnet.resolution.engine;

final class MissingInterpolationValueException extends RuntimeException {
    MissingInterpolationValueException(String message) {
        super(message);
    }
}
