package com.getnet.resolution.model;

import java.util.List;

/**
 * One unit of behavior inside a resolution config.
 *
 * <p>selectionPath defines the candidate set.</p>
 * <p>predicates refine which selected items are valid.</p>
 * <p>actions define what is materialized for each valid item.</p>
 */
public record ResolutionRule(
        String id,
        Integer priority,
        String selectionPath,
        List<RulePredicate> predicates,
        List<ActionTemplate> actions
) {
    public ResolutionRule {
        predicates = predicates == null ? List.of() : List.copyOf(predicates);
        actions = actions == null ? List.of() : List.copyOf(actions);
        priority = priority == null ? 0 : priority;
    }
}
