package com.getnet.resolution.engine;

import com.getnet.resolution.model.ResolutionResult;

/**
 * Entry point for the resolution process.
 */
public interface ResolutionEngine {

    ResolutionResult resolve(String errorCode, String payloadJson);
}
