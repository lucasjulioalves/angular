package com.getnet.resolution.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.getnet.resolution.model.ActionTemplate;
import com.getnet.resolution.model.Operator;
import com.getnet.resolution.model.PredicateScope;
import com.getnet.resolution.model.ResolutionConfig;
import com.getnet.resolution.model.ResolutionRule;
import com.getnet.resolution.model.RulePredicate;

import java.util.List;

/**
 * Programmatic examples only.
 * Real systems should hydrate these objects from Mongo documents.
 */
public final class ExampleConfigs {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private ExampleConfigs() {
    }

    public static ResolutionConfig sf90Config() {
        return new ResolutionConfig(
                "SF90",
                List.of(
                        new ResolutionRule(
                                "sf90-receive-now",
                                10,
                                "$.filters[*].value",
                                List.of(
                                        new RulePredicate(
                                                PredicateScope.CURRENT,
                                                "$.settlement_period",
                                                Operator.EQUALS,
                                                OBJECT_MAPPER.valueToTree("receive_now_2")
                                        )
                                ),
                                List.of(
                                        new ActionTemplate(
                                                "URL",
                                                OBJECT_MAPPER.createObjectNode()
                                                        .put("description", "Plano de recebimento disponível - ${value.settlement_period}")
                                                        .put("name", "${value.settlement_period}")
                                                        .put("link", "http://teste.com/v1/offerings/${offering.id}/pricing")
                                        )
                                )
                        )
                )
        );
    }
}
