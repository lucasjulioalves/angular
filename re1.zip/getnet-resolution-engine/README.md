# Resolution Engine - Explicação Técnica

Projeto em Maven + Java 21.

Comandos úteis:

```bash
mvn test
```

## Visão Geral

A solução implementa um motor de resolução baseado em configuração, onde o comportamento é definido no banco de dados (Mongo) em vez de código.

Para cada `errorCode`, existe uma configuração contendo regras. Cada regra define:

- como selecionar dados do payload (JSONPath)
- como filtrar esses dados (predicates)
- como gerar a resposta (templates com interpolação)

## Descrição do Funcionamento

A solução funciona como um mini rule engine controlado:

- Recebe o payload da API
- Usa JSONPath para selecionar elementos relevantes (ex: lista de offers)
- Cada elemento vira um contexto de execução (`value`)
- Avalia predicados sobre esse contexto
- Se passar, aplica um template configurado no banco
- Interpola dados do payload e do item atual
- Se alguma interpolação falhar, descarta apenas aquele item

Isso permite evoluir comportamento sem mudar código, apenas alterando a configuração.

---

## Fluxo de Execução

1. Recebe o payload da API
2. Busca configuração pelo `errorCode`
3. Para cada regra:
   - executa `selectionPath` (JSONPath)
   - cada item retornado vira um contexto (`value`)
   - avalia predicados
   - se passar, aplica o template
   - tenta interpolar variáveis
   - se falhar interpolação, ignora apenas aquele item
4. Retorna lista final de resultados

---

## Separação de Responsabilidades

A solução separa claramente:

- Seleção → JSONPath
- Decisão → Predicates
- Ação → Template

Isso evita acoplamento e facilita evolução.

---

## Estrutura de Configuração (Exemplo)

```json
{
  "errorCode": "SF90",
  "rules": [
    {
      "id": "sf90-receive-now",
      "priority": 10,
      "selectionPath": "$.filters[*].value",
      "predicates": [
        {
          "scope": "CURRENT",
          "path": "$.settlement_period",
          "operator": "EQUALS",
          "expectedValue": "receive_now_2"
        }
      ],
      "actions": [
        {
          "type": "URL",
          "template": {
            "description": "Plano ${value.settlement_period}",
            "name": "${value.id}",
            "link": "http://teste.com/v1/offerings/${offering.id}/pricing"
          }
        }
      ]
    }
  ]
}
```

---

## Componentes do Sistema

### ResolutionEngine

Responsável por orquestrar toda a execução.

- recebe `errorCode` e payload
- busca configuração
- executa regras
- agrega resultados finais

### ResolutionConfigRepository

Responsável por fornecer as configurações.

- busca configuração por `errorCode`
- abstrai a fonte (Mongo, memória, etc)

### InMemoryResolutionConfigRepository

Implementação simples em memória do repositório.

- usada em testes e demos
- evita acoplamento da engine com Mongo durante desenvolvimento
- em produção deve ser substituída por uma implementação real com Mongo

### ResolutionConfig

Modelo da configuração raiz.

- contém `errorCode`
- lista de `rules`

### Rule

Define uma regra de resolução.

- `selectionPath`: JSONPath para selecionar dados
- `predicates`: condições
- `actions`: templates a serem aplicados
- `priority`: ordem de execução

### ConditionEvaluator

Avalia os predicados.

- executa JSONPath no contexto (`value` ou `root`)
- aplica operador (equals, greater, etc)
- retorna true/false

### Operator

Enum de operadores.

Exemplos:

- EQUALS
- NOT_EQUALS
- GREATER_THAN
- EXISTS

### TemplateInterpolator

Responsável por substituir variáveis.

- resolve `${...}`
- suporta:
  - `${campo}` (raiz)
  - `${obj.campo}`
  - `${value.campo}` (item atual)
- se não conseguir resolver, falha controlada (item descartado)

### ResolvedAction

Modelo de saída final.

- contém os dados já interpolados
- pronto para consumo pela API/canal

---

## Fluxo Interno do Motor

```text
ResolutionEngine
  → busca config
  → itera regras
  → selectionPath (JSONPath)
  → para cada item:
      → PredicateEvaluator
      → TemplateInterpolator
  → retorna lista final
```

---

## Cenários de Teste e JSONs de Exemplo

Os testes usam arquivos em `src/test/resources/scenarios`.

Cada cenário possui:

- `config.json`: exemplo fiel do documento que poderia estar no Mongo
- `payload.json`: exemplo do payload recebido de uma API externa

Cenários incluídos:

- `sf90-offerings`
- `sf90-missing-interpolation`
- `sf90-no-match`
- `sf90-installments`
- `credit-approval-offers`
- `pricing-catalog`

Isso facilita validar a engine com formatos de APIs diferentes sem poluir o código de teste.

---

## Comportamento e Garantias

- Execução determinística
- Não lança erro por falha de interpolação de item
- Falha em um item não impacta os demais
- Retorno pode ser vazio
- Suporta múltiplos resultados

---

## Objetivo da Arquitetura

Separar comportamento de código, permitindo:

- evolução sem redeploy
- configuração dinâmica
- redução de hardcode
- maior flexibilidade para novos cenários
