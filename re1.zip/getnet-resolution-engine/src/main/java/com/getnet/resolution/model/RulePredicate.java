package com.getnet.resolution.model;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Declarative condition evaluated against ROOT, PARENT or CURRENT.
 *
 * <p>Two forms of expected value are supported:</p>
 * <ul>
 *     <li>expectedValue: static JSON value from config</li>
 *     <li>expectedTemplate: dynamic value rendered from the current execution context</li>
 * </ul>
 *
 * <p>This keeps cross-scope correlation explicit while avoiding an embedded scripting language.</p>
 */
public record RulePredicate(
        PredicateScope scope,
        String path,
        Operator operator,
        JsonNode expectedValue,
        String expectedTemplate
) {
    public RulePredicate {
        scope = scope == null ? PredicateScope.CURRENT : scope;
    }

    public RulePredicate(PredicateScope scope, String path, Operator operator, JsonNode expectedValue) {
        this(scope, path, operator, expectedValue, null);
    }
}
