package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Resolves ${...} placeholders inside templates and predicate helper strings.
 *
 * <p>Supported contexts:</p>
 * <ul>
 *     <li>${value...} -> current selected item</li>
 *     <li>${parent...} -> outer container selected by contextPath</li>
 *     <li>${root...} -> explicit access to the full payload</li>
 *     <li>${field...} -> shorthand for root access, preserved for backward compatibility</li>
 * </ul>
 *
 * <p>Semantic choice:</p>
 * if a placeholder occupies the whole string, the resolved value preserves its original JSON type.
 * This is what allows ${value} to inject an object/array/number instead of stringifying it.</p>
 */
final class TemplateInterpolator {

    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)}");

    private final ObjectMapper objectMapper;

    TemplateInterpolator(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    JsonNode interpolate(JsonNode template, JsonNode root, JsonNode current) {
        return interpolate(template, root, root, current);
    }

    JsonNode interpolate(JsonNode template, JsonNode root, JsonNode parent, JsonNode current) {
        if (template == null || template.isNull()) {
            return JsonNodeFactory.instance.nullNode();
        }

        if (template.isObject()) {
            ObjectNode result = objectMapper.createObjectNode();
            template.fields().forEachRemaining(entry ->
                    result.set(entry.getKey(), interpolate(entry.getValue(), root, parent, current))
            );
            return result;
        }

        if (template.isArray()) {
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode node : template) {
                result.add(interpolate(node, root, parent, current));
            }
            return result;
        }

        if (template.isTextual()) {
            return interpolateTextNode((TextNode) template, root, parent, current);
        }

        return template.deepCopy();
    }

    JsonNode interpolateTextTemplate(String template, JsonNode root, JsonNode parent, JsonNode current) {
        return interpolate(TextNode.valueOf(template), root, parent, current);
    }

    String interpolatePath(String template, JsonNode root, JsonNode current) {
        return interpolatePath(template, root, root, current);
    }

    /**
     * Specialized interpolation used by predicate JsonPaths.
     * Predicate paths must remain strings, so placeholders are rendered as scalar fragments only.
     */
    String interpolatePath(String template, JsonNode root, JsonNode parent, JsonNode current) {
        if (template == null || template.isBlank()) {
            return template;
        }

        Matcher matcher = PLACEHOLDER.matcher(template);
        StringBuilder builder = new StringBuilder();
        int cursor = 0;
        boolean foundAny = false;

        while (matcher.find()) {
            foundAny = true;
            String expression = matcher.group(1).trim();
            JsonNode resolved = resolveExpression(expression, root, parent, current);
            if (!resolved.isValueNode()) {
                throw new MissingInterpolationValueException(
                        "Predicate path placeholders must resolve to scalar values: " + expression
                );
            }

            builder.append(template, cursor, matcher.start());
            builder.append(asJsonPathLiteralFragment(resolved));
            cursor = matcher.end();
        }

        if (!foundAny) {
            return template;
        }

        builder.append(template, cursor, template.length());
        return builder.toString();
    }

    private JsonNode interpolateTextNode(TextNode textNode, JsonNode root, JsonNode parent, JsonNode current) {
        String original = textNode.textValue();
        Matcher matcher = PLACEHOLDER.matcher(original);

        List<PlaceholderMatch> matches = new ArrayList<>();
        while (matcher.find()) {
            String expression = matcher.group(1).trim();
            JsonNode resolved = resolveExpression(expression, root, parent, current);
            matches.add(new PlaceholderMatch(matcher.start(), matcher.end(), resolved));
        }

        if (matches.isEmpty()) {
            return textNode;
        }

        if (matches.size() == 1 && matches.get(0).coversWholeString(original.length())) {
            return matches.get(0).value().deepCopy();
        }

        StringBuilder builder = new StringBuilder();
        int cursor = 0;
        for (PlaceholderMatch match : matches) {
            builder.append(original, cursor, match.start());
            if (!match.value().isValueNode()) {
                throw new MissingInterpolationValueException(
                        "Cannot embed non-scalar value inside a larger string: " + original
                );
            }
            builder.append(match.value().asText());
            cursor = match.end();
        }
        builder.append(original, cursor, original.length());
        return TextNode.valueOf(builder.toString());
    }

    private JsonNode resolveExpression(String expression, JsonNode root, JsonNode parent, JsonNode current) {
        JsonNode source;
        String relativePath;

        if ("value".equals(expression)) {
            source = current;
            relativePath = "";
        } else if (expression.startsWith("value.")) {
            source = current;
            relativePath = expression.substring("value.".length());
        } else if ("parent".equals(expression)) {
            source = parent;
            relativePath = "";
        } else if (expression.startsWith("parent.")) {
            source = parent;
            relativePath = expression.substring("parent.".length());
        } else if ("root".equals(expression)) {
            source = root;
            relativePath = "";
        } else if (expression.startsWith("root.")) {
            source = root;
            relativePath = expression.substring("root.".length());
        } else {
            source = root;
            relativePath = expression;
        }

        JsonNode resolved = navigate(source, relativePath);
        if (resolved == null || resolved.isMissingNode() || resolved.isNull()) {
            throw new MissingInterpolationValueException("Missing interpolation value for expression: " + expression);
        }
        return resolved;
    }

    private String asJsonPathLiteralFragment(JsonNode node) {
        if (node.isTextual()) {
            return node.asText()
                    .replace("\\", "\\\\")
                    .replace("'", "\\'");
        }
        return node.asText();
    }

    private JsonNode navigate(JsonNode source, String path) {
        if (source == null) {
            return JsonNodeFactory.instance.missingNode();
        }
        if (path == null || path.isBlank()) {
            return source;
        }

        JsonNode current = source;
        for (String token : splitPath(path)) {
            current = resolveToken(current, token);
            if (current == null || current.isMissingNode()) {
                return JsonNodeFactory.instance.missingNode();
            }
        }
        return current;
    }

    private List<String> splitPath(String path) {
        List<String> parts = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int bracketDepth = 0;
        for (char ch : path.toCharArray()) {
            if (ch == '.' && bracketDepth == 0) {
                parts.add(current.toString());
                current.setLength(0);
                continue;
            }
            if (ch == '[') {
                bracketDepth++;
            } else if (ch == ']') {
                bracketDepth--;
            }
            current.append(ch);
        }
        if (current.length() > 0) {
            parts.add(current.toString());
        }
        return parts;
    }

    private JsonNode resolveToken(JsonNode current, String token) {
        if (token == null || token.isBlank()) {
            return current;
        }

        int bracketIndex = token.indexOf('[');
        String fieldName = bracketIndex >= 0 ? token.substring(0, bracketIndex) : token;
        JsonNode node = fieldName.isBlank() ? current : current.path(fieldName);
        if (node.isMissingNode()) {
            return node;
        }

        int cursor = bracketIndex;
        while (cursor >= 0 && cursor < token.length()) {
            int end = token.indexOf(']', cursor);
            if (end < 0) {
                return JsonNodeFactory.instance.missingNode();
            }
            String indexText = token.substring(cursor + 1, end).trim();
            if (indexText.isEmpty()) {
                return JsonNodeFactory.instance.missingNode();
            }
            try {
                int index = Integer.parseInt(indexText);
                node = node.path(index);
                if (node.isMissingNode()) {
                    return node;
                }
            } catch (NumberFormatException ex) {
                return JsonNodeFactory.instance.missingNode();
            }
            cursor = token.indexOf('[', end + 1);
        }
        return node;
    }

    private record PlaceholderMatch(int start, int end, JsonNode value) {
        boolean coversWholeString(int textLength) {
            return start == 0 && end == textLength;
        }
    }
}
