package com.getnet.resolution.model;

/**
 * Defines which JSON node a predicate should inspect.
 * ROOT = full payload, PARENT = outer context selected by contextPath, CURRENT = item selected by selectionPath.
 */
public enum PredicateScope {
    CURRENT,
    PARENT,
    ROOT
}
