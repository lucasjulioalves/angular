package com.getnet.resolution.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.getnet.resolution.model.ActionTemplate;
import com.getnet.resolution.model.ResolutionConfig;
import com.getnet.resolution.model.ResolutionResult;
import com.getnet.resolution.model.ResolutionRule;
import com.getnet.resolution.model.ResolvedAction;
import com.getnet.resolution.repository.ResolutionConfigRepository;

import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Default implementation of the resolution engine.
 *
 * <p>Execution pipeline:</p>
 * <ol>
 *     <li>load config by error/detail code</li>
 *     <li>select optional outer contexts via contextPath</li>
 *     <li>select items inside each context via selectionPath</li>
 *     <li>evaluate predicates/predicateGroups using ROOT, PARENT and CURRENT</li>
 *     <li>materialize actions through template interpolation</li>
 * </ol>
 */
public final class DefaultResolutionEngine implements ResolutionEngine {

    private final ResolutionConfigRepository repository;
    private final ObjectMapper objectMapper;
    private final JsonPathQueryExecutor queryExecutor;
    private final PredicateEvaluator predicateEvaluator;
    private final TemplateInterpolator templateInterpolator;

    public DefaultResolutionEngine(ResolutionConfigRepository repository) {
        this(repository, new ObjectMapper());
    }

    public DefaultResolutionEngine(ResolutionConfigRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.queryExecutor = new JsonPathQueryExecutor(objectMapper);
        this.templateInterpolator = new TemplateInterpolator(objectMapper);
        this.predicateEvaluator = new PredicateEvaluator(queryExecutor, templateInterpolator);
    }

    @Override
    public ResolutionResult resolve(String errorCode, String payloadJson) {
        Optional<ResolutionConfig> configOptional = repository.findByErrorCode(errorCode);
        if (configOptional.isEmpty()) {
            return ResolutionResult.empty(errorCode);
        }

        JsonNode root = parse(payloadJson);
        List<ResolvedAction> resolvedActions = new ArrayList<>();

        ResolutionConfig config = configOptional.get();
        for (ResolutionRule rule : config.rules()) {
            resolveRule(errorCode, root, rule, resolvedActions);
        }

        return new ResolutionResult(errorCode, List.copyOf(resolvedActions));
    }

    private void resolveRule(String errorCode, JsonNode root, ResolutionRule rule, List<ResolvedAction> resolvedActions) {
        List<JsonNode> contexts = hasText(rule.contextPath())
                ? queryExecutor.read(root, rule.contextPath())
                : List.of(root);

        for (JsonNode parent : contexts) {
            List<JsonNode> selectedItems = hasText(rule.selectionPath())
                    ? queryExecutor.read(parent, rule.selectionPath())
                    : List.of(parent);

            for (JsonNode current : selectedItems) {
                if (!predicateEvaluator.matchesRule(rule, root, parent, current)) {
                    continue;
                }
                materializeActions(errorCode, root, parent, rule, current, resolvedActions);
            }
        }
    }

    private void materializeActions(
            String errorCode,
            JsonNode root,
            JsonNode parent,
            ResolutionRule rule,
            JsonNode current,
            List<ResolvedAction> resolvedActions
    ) {
        for (ActionTemplate actionTemplate : rule.actions()) {
            try {
                JsonNode resolvedPayload = templateInterpolator.interpolate(actionTemplate.template(), root, parent, current);
                resolvedActions.add(new ResolvedAction(
                        errorCode,
                        rule.id(),
                        actionTemplate.type(),
                        resolvedPayload
                ));
            } catch (MissingInterpolationValueException ignored) {
                // One bad action instance must not break the whole resolution.
            }
        }
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private JsonNode parse(String payloadJson) {
        try {
            return objectMapper.readTree(payloadJson);
        } catch (Exception ex) {
            throw new UncheckedIOException(new java.io.IOException("Invalid payload JSON", ex));
        }
    }
}
