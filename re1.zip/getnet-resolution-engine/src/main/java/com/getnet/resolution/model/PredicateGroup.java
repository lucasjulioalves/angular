package com.getnet.resolution.model;

import java.util.List;

/**
 * A predicate group adds controlled boolean composition without turning the engine into a script runtime.
 *
 * <p>Design choice:</p>
 * <ul>
 *     <li>groups are evaluated independently</li>
 *     <li>the rule matches only if every group matches</li>
 *     <li>inside a group, the mode defines ALL vs ANY semantics</li>
 * </ul>
 */
public record PredicateGroup(
        PredicateMatchMode mode,
        List<RulePredicate> predicates
) {
    public PredicateGroup {
        mode = mode == null ? PredicateMatchMode.ALL : mode;
        predicates = predicates == null ? List.of() : List.copyOf(predicates);
    }
}
