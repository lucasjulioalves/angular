package com.getnet.resolution.model;

/**
 * Match mode for a predicate group.
 * ALL = every predicate must match, ANY = at least one predicate must match.
 */
public enum PredicateMatchMode {
    ALL,
    ANY
}
